function calculateFactorial() {
  const input = parseInt(document.getElementById("numberInput").value);
  const output = document.getElementById("output");

  if (isNaN(input) || input < 0) {
    output.textContent = "Please enter a non-negative number.";
    return;
  }

  let factorial = 1;
  for (let i = 1; i <= input; i++) {
    factorial *= i;
  }

  output.textContent = `${input}! = ${factorial}`;
}

// Theme Toggle
function setTheme(mode) {
  document.documentElement.setAttribute("data-bs-theme", mode);
}